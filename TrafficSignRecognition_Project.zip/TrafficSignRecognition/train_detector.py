"""Train a one-class (sign or traffic light) YOLO detector on the road images.
The cropped-sign CNN handles the finer class name in a second stage.
"""
import argparse
import json
import shutil
from pathlib import Path

import torch


def train_detector(data_root='data', epochs=35, imgsz=640, batch=8,
                   device=None, base_model='yolo11n.pt', workers=0):
    from ultralytics import YOLO
    data_yaml = Path(data_root).resolve() / 'detection' / 'data.yaml'
    if not data_yaml.is_file():
        raise FileNotFoundError(f'Missing dataset: {data_yaml}. Run prepare_data.py first.')
    if device is None:
        device = 0 if torch.cuda.is_available() else 'cpu'
    print('Detector training device:', device)
    print('The first run may download pretrained YOLO backbone weights.')
    model = YOLO(base_model)
    model.train(
        data=str(data_yaml), epochs=epochs, imgsz=imgsz, batch=batch,
        device=device, workers=workers, patience=12,
        project=str(Path('runs').resolve()), name='traffic_sign_detector',
        exist_ok=True, verbose=True, plots=True,
    )
    best = Path(model.trainer.best)
    if not best.is_file():
        raise FileNotFoundError(f'Trained detector checkpoint not found at: {best}')
    destination = Path('models/sign_detector.pt')
    destination.parent.mkdir(exist_ok=True, parents=True)
    shutil.copyfile(best, destination)
    print('Detector saved:', destination.resolve())
    return destination


def evaluate_detector(data_root='data', checkpoint='models/sign_detector.pt', imgsz=640, device=None):
    from ultralytics import YOLO
    if device is None:
        device = 0 if torch.cuda.is_available() else 'cpu'
    model = YOLO(str(checkpoint))
    metrics = model.val(data=str(Path(data_root).resolve() / 'detection' / 'data.yaml'),
                        split='test', imgsz=imgsz, device=device, workers=0,
                        project=str(Path('runs').resolve()), name='detector_test', exist_ok=True)
    results = {'precision': float(metrics.box.mp), 'recall': float(metrics.box.mr),
               'map50': float(metrics.box.map50), 'map50_95': float(metrics.box.map)}
    Path('models/detector_test_metrics.json').write_text(json.dumps(results, indent=2), encoding='utf8')
    print('Detector test metrics:', results)
    return results


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--data', default='data')
    parser.add_argument('--epochs', type=int, default=35)
    parser.add_argument('--imgsz', type=int, default=640)
    parser.add_argument('--batch', type=int, default=8)
    parser.add_argument('--device', default=None, help='0 for NVIDIA GPU; cpu for CPU')
    parser.add_argument('--base-model', default='yolo11n.pt')
    parser.add_argument('--evaluate-only', action='store_true')
    args = parser.parse_args()
    if not args.evaluate_only:
        train_detector(args.data, args.epochs, args.imgsz, args.batch, args.device, args.base_model)
    evaluate_detector(args.data, imgsz=args.imgsz, device=args.device)
