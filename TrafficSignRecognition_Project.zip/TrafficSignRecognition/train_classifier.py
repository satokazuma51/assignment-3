"""Standalone alternative to the training cell in the notebook.
Run AFTER prepare_data.py.  The notebook contains the same training loop.
"""
import argparse
import json
import random
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import torch
from sklearn.metrics import accuracy_score, f1_score, classification_report
from torch import nn
from torch.utils.data import DataLoader

from src.classification_data import CropDataset
from src.model import TrafficSignCNN, IMAGE_SIZE


def one_epoch(model, loader, criterion, device, optimizer=None):
    train = optimizer is not None
    model.train(train)
    all_true, all_pred, total_loss = [], [], 0.
    with torch.set_grad_enabled(train):
        for images, target in loader:
            images, target = images.to(device), target.to(device)
            if train:
                optimizer.zero_grad(set_to_none=True)
            logits = model(images)
            loss = criterion(logits, target)
            if train:
                loss.backward()
                optimizer.step()
            total_loss += loss.item() * images.size(0)
            all_true.extend(target.cpu().tolist())
            all_pred.extend(logits.argmax(1).cpu().tolist())
    return {
        'loss': total_loss / len(loader.dataset),
        'accuracy': accuracy_score(all_true, all_pred),
        'f1_weighted': f1_score(all_true, all_pred, average='weighted', zero_division=0),
    }


def run_training(data_root='data', model_out='models/sign_classifier.pt',
                 epochs=15, batch_size=64, learning_rate=.001, seed=42,
                 init_checkpoint=None):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    root = Path(data_root)
    classes = json.loads((root / 'classes.json').read_text(encoding='utf8'))
    train_data = CropDataset(root, 'train', train_transform=True)
    valid_data = CropDataset(root, 'val')
    train_loader = DataLoader(train_data, batch_size=batch_size, shuffle=True, num_workers=0)
    val_loader = DataLoader(valid_data, batch_size=batch_size, shuffle=False, num_workers=0)
    model = TrafficSignCNN(len(classes)).to(device)
    starting_f1 = -1.0
    if init_checkpoint:
        previous = torch.load(init_checkpoint, map_location=device, weights_only=True)
        if previous['class_names'] != classes:
            raise ValueError('Checkpoint class names do not match prepared data. Retrain after changing datasets.')
        model.load_state_dict(previous['model_state_dict'])
        starting_f1 = float(previous.get('validation_f1', -1.0))
        print(f'Initialized CNN from {init_checkpoint}, previous best validation F1={starting_f1:.4f}. Adam optimizer restarts.')
    counts = train_data.label_counts()
    max_count = max(counts.values())
    weights = [min(4., (max_count / max(1, counts[i])) ** .5) for i in range(len(classes))]
    criterion = nn.CrossEntropyLoss(weight=torch.tensor(weights, device=device))
    optimizer = torch.optim.Adam(model.parameters(), lr=learning_rate)
    out = Path(model_out)
    out.parent.mkdir(parents=True, exist_ok=True)
    history = {'train_loss': [], 'val_loss': [], 'train_accuracy': [], 'val_accuracy': [], 'val_f1': []}
    best_f1 = starting_f1
    for epoch in range(1, epochs + 1):
        tr = one_epoch(model, train_loader, criterion, device, optimizer)
        va = one_epoch(model, val_loader, criterion, device)
        for k, v in [('train_loss', tr['loss']), ('val_loss', va['loss']),
                     ('train_accuracy', tr['accuracy']), ('val_accuracy', va['accuracy']),
                     ('val_f1', va['f1_weighted'])]:
            history[k].append(v)
        hist_path = out.parent / 'classifier_history.json'
        hist_path.write_text(json.dumps(history, indent=2), encoding='utf8')
        print(f'Epoch {epoch:02d}/{epochs} train loss={tr["loss"]:.4f} '
              f'val loss={va["loss"]:.4f} val acc={va["accuracy"]:.3f} '
              f'val weighted-F1={va["f1_weighted"]:.3f}')
        if va['f1_weighted'] > best_f1:
            best_f1 = va['f1_weighted']
            torch.save({'model_state_dict': model.state_dict(), 'class_names': classes,
                        'image_size': IMAGE_SIZE, 'epoch': epoch, 'validation_f1': best_f1}, out)

    hist_path = out.parent / 'classifier_history.json'
    hist_path.write_text(json.dumps(history, indent=2), encoding='utf8')
    fig, axes = plt.subplots(1, 2, figsize=(11, 4))
    axes[0].plot(history['train_loss'], label='Train')
    axes[0].plot(history['val_loss'], label='Validation')
    axes[0].set(title='Classification loss', xlabel='Epoch', ylabel='Cross-entropy')
    axes[1].plot(history['train_accuracy'], label='Train accuracy')
    axes[1].plot(history['val_accuracy'], label='Validation accuracy')
    axes[1].set(title='Classification accuracy', xlabel='Epoch', ylabel='Accuracy')
    for a in axes: a.legend(); a.grid(alpha=.25)
    fig.tight_layout()
    fig.savefig(out.parent / 'classifier_learning_curves.png', dpi=140)
    plt.close(fig)
    print(f'Best validation F1: {best_f1:.3f}; model saved to {out}')
    return out


def evaluate_test(data_root='data', checkpoint='models/sign_classifier.pt', batch_size=64):
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    ck = torch.load(checkpoint, map_location=device, weights_only=True)
    model = TrafficSignCNN(len(ck['class_names'])).to(device)
    model.load_state_dict(ck['model_state_dict'])
    model.eval()
    ds = CropDataset(data_root, 'test')
    loader = DataLoader(ds, batch_size=batch_size, shuffle=False, num_workers=0)
    actual, predicted = [], []
    with torch.inference_mode():
        for img, labels in loader:
            pred = model(img.to(device)).argmax(1).cpu().tolist()
            actual.extend(labels.tolist())
            predicted.extend(pred)
    a = accuracy_score(actual, predicted)
    f1 = f1_score(actual, predicted, average='weighted', zero_division=0)
    report = classification_report(actual, predicted, labels=list(range(len(ck['class_names']))),
                                   target_names=ck['class_names'], zero_division=0)
    print(f'Test accuracy: {a:.4f} / Test weighted F1: {f1:.4f}\n{report}')
    result = {'test_accuracy': a, 'test_f1_weighted': f1, 'n_test_crops': len(actual)}
    Path(checkpoint).parent.joinpath('classifier_test_metrics.json').write_text(json.dumps(result, indent=2), encoding='utf8')
    return result


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--data', default='data')
    parser.add_argument('--epochs', type=int, default=15)
    parser.add_argument('--batch', type=int, default=64)
    parser.add_argument('--lr', type=float, default=.001)
    parser.add_argument('--evaluate-only', action='store_true')
    parser.add_argument('--init-checkpoint', default=None, help='Initialize from a previous CNN checkpoint and restart Adam')
    args = parser.parse_args()
    if not args.evaluate_only:
        run_training(data_root=args.data, epochs=args.epochs, batch_size=args.batch,
                     learning_rate=args.lr, init_checkpoint=args.init_checkpoint)
    evaluate_test(data_root=args.data)
