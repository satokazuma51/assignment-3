"""Command line preprocessing: python prepare_data.py --gtsdb ... --roboflow ..."""
import argparse
import json
from src.preparation import prepare_datasets


def main():
    p = argparse.ArgumentParser(description='Prepare annotated road images and class crops')
    p.add_argument('--gtsdb', default='archive (2).zip', help='Path to GTSDB ZIP')
    p.add_argument('--roboflow', default='archive (1)(1).zip', help='Path to Roboflow ZIP')
    p.add_argument('--extra-root', default=None, help='Optional extracted third YOLO dataset folder')
    p.add_argument('--output', default='data', help='Prepared output data folder')
    args = p.parse_args()
    summary = prepare_datasets(args.gtsdb, args.roboflow, args.output, args.extra_root)
    print(json.dumps(summary['stats'], indent=2))
    print('Sources:', summary['sources'])
    print(f"Classifier categories: {len(summary['class_names'])}")
    print(f"Data ready in: {args.output}")


if __name__ == '__main__':
    main()
