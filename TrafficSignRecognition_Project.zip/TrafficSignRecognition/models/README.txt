This folder contains a PRELIMINARY trained custom CNN sign_classifier.pt.
It is not a final accurate model and needs more training.
Run train_detector.py to create sign_detector.pt for full-image bounding boxes.
