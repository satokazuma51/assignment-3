import json
import unittest
from pathlib import Path

import torch
from PIL import Image

from src.labels import GTSDB_NAMES, normalize_label
from src.model import TrafficSignCNN
from src.preparation import parse_yolo, _box_pixels, Record, Box, _gtsdb_split
from src.inference import classify_and_annotate


class FakeBoxes:
    xyxy = torch.tensor([[12, 18, 42, 56]], dtype=torch.float32)
    conf = torch.tensor([.91], dtype=torch.float32)


class FakeResult:
    boxes = FakeBoxes()


class FakeDetector:
    def predict(self, **kwargs):
        assert kwargs['source'].shape == (100, 100, 3)
        return [FakeResult()]


class FakeCNN(torch.nn.Module):
    def forward(self, x):
        logits = torch.zeros(x.size(0), 2)
        logits[:, 0] = 8.0
        return logits


class PipelineTests(unittest.TestCase):
    def test_exact_source_mapping(self):
        self.assertEqual(len(GTSDB_NAMES), 43)
        self.assertEqual(GTSDB_NAMES[14], 'Stop')
        self.assertEqual(normalize_label('speed limit 50 km/h'), 'Speed Limit 50')
        self.assertEqual(normalize_label('Stop'), 'Stop')
        self.assertNotEqual(GTSDB_NAMES[0], 'Green Light')  # no numeric ID shortcut

    def test_yolo_annotations(self):
        self.assertEqual(parse_yolo(''), [])
        self.assertEqual(len(parse_yolo('3 0.5 0.4 0.1 0.2\n')), 1)
        with self.assertRaises(ValueError):
            parse_yolo('1 0.1 0.2 0.3')
        with self.assertRaises(ValueError):
            parse_yolo('1 0.5 0.5 3.0 0.5')
        self.assertEqual(_box_pixels(Box(3,.5,.5,.4,.2), 100,100,padding_fraction=0), (30,40,70,60))

    def test_split_preserves_singleton_class(self):
        boxes = [Box(0,.5,.5,.2,.2)]
        records = [Record('gtsdb','Train','train',f'{i}.jpg','x','x',boxes,[f'Sign {i}']) for i in range(5)]
        _gtsdb_split(records,val_fraction=.8)
        self.assertTrue(all(r.split=='train' for r in records))

    def test_classifier_forward_backward(self):
        model = TrafficSignCNN(5)
        batch = torch.rand(2,3,64,64)
        logits = model(batch)
        self.assertEqual(tuple(logits.shape), (2,5))
        loss = torch.nn.CrossEntropyLoss()(logits, torch.tensor([1,4]))
        loss.backward()
        self.assertTrue(any(p.grad is not None for p in model.parameters()))

    def test_full_image_prediction_and_boxes(self):
        orig = Image.new('RGB',(100,100),(222,222,222))
        res, boxes = classify_and_annotate(orig,FakeDetector(),FakeCNN(),
                                           ['Speed Limit 50', 'Stop'],torch.device('cpu'))
        self.assertEqual(res.size, orig.size)
        self.assertEqual(len(boxes),1)
        self.assertEqual(boxes[0]['sign'],'Speed Limit 50')
        self.assertEqual(boxes[0]['box'],[12,18,42,56])
        self.assertGreater(boxes[0]['class_confidence'],.99)

    def test_prepared_data_if_available(self):
        path = Path('data/summary.json')
        if not path.exists():
            self.skipTest('Skip real ZIP test: run prepare_data.py to enable')
        s = json.loads(path.read_text(encoding='utf8'))
        self.assertEqual(sum(x['images'] for x in s['stats'].values()), 5869)
        self.assertEqual(len(s['class_names']),46)
        self.assertEqual(s['stats']['test']['unknown_class_boxes'],8)


if __name__=='__main__':
    unittest.main()
