"""Loads sign crops and classification labels produced by prepare_data.py."""
import csv
from collections import Counter
from pathlib import Path
from PIL import Image
from torch.utils.data import Dataset
from torchvision import transforms
from .model import IMAGE_SIZE, MEAN, STD


def make_transform(train: bool = False):
    if train:
        return transforms.Compose([
            transforms.Resize((IMAGE_SIZE + 8, IMAGE_SIZE + 8)),
            transforms.RandomCrop((IMAGE_SIZE, IMAGE_SIZE)),
            transforms.RandomRotation(9),
            transforms.ColorJitter(brightness=.18, contrast=.17, saturation=.12),
            transforms.ToTensor(), transforms.Normalize(MEAN, STD),
        ])
    return transforms.Compose([
        transforms.Resize((IMAGE_SIZE, IMAGE_SIZE)),
        transforms.ToTensor(), transforms.Normalize(MEAN, STD),
    ])


class CropDataset(Dataset):
    def __init__(self, data_root: str | Path, split: str, train_transform=False):
        root = Path(data_root)
        with (root / 'classification' / f'{split}.csv').open(newline='', encoding='utf8') as f:
            self.rows = [(row['image'], int(row['label'])) for row in csv.DictReader(f)]
        self.root = root / 'classification'
        self.transform = make_transform(train_transform)
        if not self.rows:
            raise ValueError(f'No labeled crops in split {split}; check dataset preparation.')

    def __len__(self):
        return len(self.rows)

    def __getitem__(self, idx):
        rel, label = self.rows[idx]
        with Image.open(self.root / rel) as im:
            img = self.transform(im.convert('RGB'))
        return img, label

    def label_counts(self):
        return Counter(label for _, label in self.rows)
