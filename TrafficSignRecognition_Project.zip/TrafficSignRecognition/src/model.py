"""Custom convolutional neural network for cropped traffic signs."""
import torch
from torch import nn

IMAGE_SIZE = 64
MEAN = (0.5, 0.5, 0.5)
STD = (0.5, 0.5, 0.5)


class TrafficSignCNN(nn.Module):
    """A small CNN trained from scratch (not a pretrained classifier)."""

    def __init__(self, num_classes: int):
        super().__init__()
        self.features = nn.Sequential(
            nn.Conv2d(3, 24, kernel_size=3, padding=1),
            nn.BatchNorm2d(24), nn.ReLU(inplace=True),
            nn.MaxPool2d(2),                       # 64 -> 32
            nn.Conv2d(24, 48, kernel_size=3, padding=1),
            nn.BatchNorm2d(48), nn.ReLU(inplace=True),
            nn.MaxPool2d(2),                       # 32 -> 16
            nn.Conv2d(48, 96, kernel_size=3, padding=1),
            nn.BatchNorm2d(96), nn.ReLU(inplace=True),
            nn.MaxPool2d(2),                       # 16 -> 8
            nn.Conv2d(96, 128, kernel_size=3, padding=1),
            nn.BatchNorm2d(128), nn.ReLU(inplace=True),
            nn.AdaptiveAvgPool2d((1, 1)),
        )
        self.classifier = nn.Sequential(
            nn.Flatten(), nn.Dropout(p=0.25),
            nn.Linear(128, 128), nn.ReLU(inplace=True),
            nn.Dropout(p=0.25), nn.Linear(128, num_classes),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.classifier(self.features(x))
