"""Two-stage inference: YOLO bounding boxes -> custom PyTorch CNN class names."""
import io
from pathlib import Path

import numpy as np
import torch
from PIL import Image, ImageDraw, ImageFont, ImageOps

from .classification_data import make_transform
from .model import TrafficSignCNN


def load_models(detector_path='models/sign_detector.pt',
                classifier_path='models/sign_classifier.pt'):
    from ultralytics import YOLO
    detector_path = Path(detector_path)
    classifier_path = Path(classifier_path)
    if not detector_path.is_file():
        raise FileNotFoundError(f'Missing detector checkpoint: {detector_path}')
    if not classifier_path.is_file():
        raise FileNotFoundError(f'Missing classifier checkpoint: {classifier_path}')
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    ck = torch.load(classifier_path, map_location=device, weights_only=True)
    names = ck['class_names']
    cnn = TrafficSignCNN(len(names)).to(device)
    cnn.load_state_dict(ck['model_state_dict'])
    cnn.eval()
    detector = YOLO(str(detector_path))
    return detector, cnn, names, device


def classify_and_annotate(image: Image.Image, detector, classifier, names,
                          device, detection_threshold=.25, class_threshold=.45,
                          detector_imgsz=640):
    """Returns (RGB annotated image, individual detections).

    Detection confidence measures localization probability. CNN softmax is
    a model score, not a calibrated real-world correctness guarantee.
    """
    original = ImageOps.exif_transpose(image).convert('RGB')
    width, height = original.size
    if width < 8 or height < 8:
        raise ValueError('Image is too small for reliable recognition.')
    # Ultralytics interprets numpy image input as BGR (like OpenCV).
    bgr = np.ascontiguousarray(np.asarray(original)[:, :, ::-1])
    results = detector.predict(source=bgr, conf=detection_threshold,
                               imgsz=detector_imgsz, device=str(device), verbose=False)
    boxdata = results[0].boxes
    detections, crops, coords = [], [], []
    if boxdata is not None:
        coords_xyxy = boxdata.xyxy.cpu().numpy()
        det_scores = boxdata.conf.cpu().numpy()
        for box, dscore in zip(coords_xyxy, det_scores):
            x1, y1, x2, y2 = [float(v) for v in box]
            x1, y1 = max(0, int(round(x1))), max(0, int(round(y1)))
            x2, y2 = min(width, int(round(x2))), min(height, int(round(y2)))
            if x2 - x1 < 3 or y2 - y1 < 3:
                continue
            # A little context makes classification more robust to imperfect boxes.
            px, py = max(1, int((x2 - x1) * .04)), max(1, int((y2 - y1) * .04))
            crop = original.crop((max(0, x1-px), max(0, y1-py),
                                  min(width, x2+px), min(height, y2+py)))
            crops.append(make_transform()(crop))
            coords.append(([x1, y1, x2, y2], float(dscore)))
    if crops:
        with torch.inference_mode():
            score, category = torch.softmax(classifier(torch.stack(crops).to(device)), dim=1).max(1)
        for (box, det_conf), cl_conf, class_id in zip(coords, score.cpu().tolist(), category.cpu().tolist()):
            label = names[class_id] if cl_conf >= class_threshold else 'Uncertain sign'
            detections.append({'box': box, 'sign': label, 'detection_confidence': det_conf,
                               'class_confidence': cl_conf})

    annotated = original.copy()
    draw = ImageDraw.Draw(annotated)
    font = ImageFont.load_default()
    for item in detections:
        x1, y1, x2, y2 = item['box']
        draw.rectangle((x1, y1, x2, y2), outline='#06D6A0', width=max(2, min(width, height)//250))
        text = f"{item['sign']} ({item['class_confidence']:.0%})"
        l, t, r, b = draw.textbbox((0, 0), text, font=font)
        text_height, text_width = b-t+6, r-l+8
        tx, ty = max(0, min(x1, width-text_width)), max(0, y1-text_height)
        draw.rectangle((tx, ty, tx + text_width, ty + text_height), fill='#04382E')
        draw.text((tx + 4, ty + 3), text, font=font, fill='white')
    return annotated, detections


def png_bytes(pil_image):
    output = io.BytesIO()
    pil_image.save(output, format='PNG')
    return output.getvalue()
