"""Canonical traffic-control labels, shared by preparation and inference.

GTSDB class indices follow the conventional German Traffic Sign Benchmark
0-42 class order. The Roboflow source provides its class names in data.yaml.
Never treat equal *numeric* IDs from these two sources as the same class.
"""
import re

GTSDB_NAMES = [
    "Speed Limit 20", "Speed Limit 30", "Speed Limit 50", "Speed Limit 60",
    "Speed Limit 70", "Speed Limit 80", "End Speed Limit 80", "Speed Limit 100",
    "Speed Limit 120", "No Passing", "No Passing Heavy Vehicles",
    "Right Of Way Next Intersection", "Priority Road", "Yield", "Stop",
    "No Vehicles", "Heavy Vehicles Prohibited", "No Entry", "General Caution",
    "Curve Left", "Curve Right", "Double Curve", "Bumpy Road",
    "Slippery Road", "Road Narrows Right", "Road Work", "Traffic Signals Ahead",
    "Pedestrians", "Children Crossing", "Bicycles Crossing", "Ice Or Snow",
    "Wild Animals Crossing", "End All Restrictions", "Turn Right Ahead",
    "Turn Left Ahead", "Ahead Only", "Straight Or Right", "Straight Or Left",
    "Keep Right", "Keep Left", "Roundabout Mandatory", "End No Passing",
    "End No Passing Heavy Vehicles",
]
assert len(GTSDB_NAMES) == 43


def normalize_label(label: str) -> str:
    """Standardize obvious name variants, preserving distinctions among signs."""
    value = re.sub(r"\s+", " ", str(label).strip())
    m = re.fullmatch(r"(?i)speed[ _-]*limit[ _-]*(\d+)(?:\s*(?:km/?h|kph))?", value)
    if m:
        return f"Speed Limit {int(m.group(1))}"
    if value.lower() in {"stop", "stop sign"}:
        return "Stop"
    if value.lower() in {"green light", "green traffic light"}:
        return "Green Light"
    if value.lower() in {"red light", "red traffic light"}:
        return "Red Light"
    return value
