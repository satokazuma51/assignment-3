"""Prepare both supplied YOLO datasets without mixing incompatible class IDs.

Dataset inputs:
  GTSDB archive contains GTSDB_Train_and_Test/Train|Test/images|labels
  Roboflow archive contains car/train|valid|test/images|labels and data.yaml
The third optional input is a local YOLO-format directory with a data.yaml.
"""
import csv
import io
import json
import random
import shutil
import zipfile
from collections import Counter
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

import yaml
from PIL import Image, ImageOps, UnidentifiedImageError

from .labels import GTSDB_NAMES, normalize_label

IMAGE_SUFFIXES = {'.jpg', '.jpeg', '.png', '.webp'}


@dataclass
class Box:
    class_id: int
    xc: float
    yc: float
    w: float
    h: float


@dataclass
class Record:
    source: str
    source_split: str
    split: str
    original_name: str
    img_ref: str
    ann_ref: Optional[str]
    boxes: list[Box]
    names: list[str]


def parse_yolo(txt: str) -> list[Box]:
    boxes = []
    for line in txt.splitlines():
        s = line.strip()
        if not s:
            continue
        fields = s.split()
        if len(fields) != 5:
            raise ValueError(f'Expected YOLO class xc yc w h, got: {line!r}')
        cid = int(fields[0]); xc, yc, w, h = map(float, fields[1:])
        if not (0 <= xc <= 1 and 0 <= yc <= 1 and 0 < w <= 1 and 0 < h <= 1):
            raise ValueError(f'Invalid normalized bounding box: {line!r}')
        boxes.append(Box(cid, xc, yc, w, h))
    return boxes


def _zip_data(zf, name):
    if name is None:
        return b''
    try:
        return zf.read(name)
    except KeyError:
        return b''


def _list_zip_images(zf, source: str, split: str, directory: str,
                     name_lookup: dict[int, str], source_split: str):
    prefix = f'{directory}/images/'
    names = set(zf.namelist())
    result = []
    for img_path in sorted(n for n in names if n.startswith(prefix) and Path(n).suffix.lower() in IMAGE_SUFFIXES):
        ann_path = f'{directory}/labels/{Path(img_path).stem}.txt'
        if ann_path not in names:
            ann_path = None
        boxes = parse_yolo(_zip_data(zf, ann_path).decode('utf-8-sig'))
        labels = []
        for b in boxes:
            if b.class_id not in name_lookup:
                if source == 'gtsdb' and b.class_id == 100:
                    labels.append('')  # Unsupported label on one GTSDB test box.
                    continue
                raise ValueError(f'Unknown {source} class ID {b.class_id} in {img_path}')
            labels.append(normalize_label(name_lookup[b.class_id]))
        result.append(Record(source, source_split, split, Path(img_path).name, img_path, ann_path, boxes, labels))
    return result


def _gtsdb_split(train: list[Record], val_fraction: float = .2, seed: int = 42):
    # Class-aware split: do not move the only training example of a rare sign to val.
    rng = random.Random(seed)
    shuffled = train[:]
    rng.shuffle(shuffled)
    available = Counter(label for r in train for label in set(r.names) if label)
    val_count = 0
    val_target = round(val_fraction * len(train))
    for r in shuffled:
        cls = set(label for label in r.names if label)
        if val_count < val_target and all(available[c] > 1 for c in cls):
            r.split = 'val'
            val_count += 1
            for c in cls:
                available[c] -= 1
        else:
            r.split = 'train'
    return train


def _collect_gtsdb(gtsdb_zip: Path):
    with zipfile.ZipFile(gtsdb_zip) as zf:
        prefix = 'GTSDB_Train_and_Test'
        lookup = dict(enumerate(GTSDB_NAMES))
        train = _list_zip_images(zf, 'gtsdb', 'train', f'{prefix}/Train', lookup, 'Train')
        test = _list_zip_images(zf, 'gtsdb', 'test', f'{prefix}/Test', lookup, 'Test')
    if len(train) != 600 or len(test) != 300:
        raise ValueError('Unexpected GTSDB layout: expected 600 train and 300 test images.')
    return _gtsdb_split(train) + test


def _read_names(config: dict):
    names = config.get('names')
    if isinstance(names, list):
        return {i: str(n) for i, n in enumerate(names)}
    if isinstance(names, dict):
        return {int(k): str(v) for k, v in names.items()}
    raise ValueError('YOLO data.yaml needs a names list or mapping.')


def _collect_roboflow(roboflow_zip: Path):
    with zipfile.ZipFile(roboflow_zip) as zf:
        conf = yaml.safe_load(zf.read('car/data.yaml'))
        lookup = _read_names(conf)
        results = []
        for source_split, split in [('train', 'train'), ('valid', 'val'), ('test', 'test')]:
            results.extend(_list_zip_images(zf, 'roboflow', split, f'car/{source_split}', lookup, source_split))
    if len(results) != 4969:
        raise ValueError(f'Unexpected Roboflow archive count ({len(results)}); expected 4969.')
    return results


def _collect_extra(extra_root: Path):
    # Optional dataset must already be extracted in a conventional YOLO directory.
    candidates = [extra_root / 'data.yaml', *extra_root.glob('*/data.yaml')]
    yaml_file = next((p for p in candidates if p.exists()), None)
    if yaml_file is None:
        raise ValueError('Optional third dataset needs data.yaml and train/images, train/labels folders.')
    root = yaml_file.parent
    conf = yaml.safe_load(yaml_file.read_text(encoding='utf8'))
    lookup = _read_names(conf)
    records = []
    extra_splits = [('train', 'train'), ('test', 'test')]
    if (root / 'valid' / 'images').is_dir():
        extra_splits.append(('valid', 'val'))
    elif (root / 'val' / 'images').is_dir():
        extra_splits.append(('val', 'val'))
    for source_split, split in extra_splits:
        images = root / source_split / 'images'
        if not images.is_dir():
            continue
        for img in sorted(images.iterdir()):
            if img.suffix.lower() not in IMAGE_SUFFIXES:
                continue
            lbl = root / source_split / 'labels' / (img.stem + '.txt')
            boxes = parse_yolo(lbl.read_text(encoding='utf8-sig') if lbl.exists() else '')
            labels = []
            for b in boxes:
                if b.class_id not in lookup:
                    raise ValueError(f'Unknown third-dataset class ID {b.class_id}: {lbl}')
                labels.append(normalize_label(lookup[b.class_id]))
            records.append(Record('extra', source_split, split, img.name, str(img), str(lbl) if lbl.exists() else None, boxes, labels))
    if not records or not any(r.split == 'train' for r in records):
        raise ValueError('Third dataset must contain train/images and matching YOLO labels.')
    return records


def _load_original(record: Record, zips):
    if record.source == 'extra':
        return Path(record.img_ref).read_bytes()
    return zips[record.source].read(record.img_ref)


def _box_pixels(box: Box, width, height, padding_fraction: float = .07):
    half_w = box.w * width / 2
    half_h = box.h * height / 2
    cx, cy = box.xc * width, box.yc * height
    pad_x, pad_y = half_w * padding_fraction, half_h * padding_fraction
    x1 = max(0, round(cx - half_w - pad_x))
    y1 = max(0, round(cy - half_h - pad_y))
    x2 = min(width, round(cx + half_w + pad_x))
    y2 = min(height, round(cy + half_h + pad_y))
    return x1, y1, x2, y2


def prepare_datasets(gtsdb_zip: str | Path, roboflow_zip: str | Path,
                     output_dir: str | Path = 'data', extra_root: str | Path | None = None):
    gtsdb_zip = Path(gtsdb_zip).expanduser().resolve()
    roboflow_zip = Path(roboflow_zip).expanduser().resolve()
    for p in [gtsdb_zip, roboflow_zip]:
        if not p.is_file():
            raise FileNotFoundError(f'Dataset ZIP not found: {p}')
    output = Path(output_dir).expanduser().resolve()
    if (output / 'summary.json').exists():
        raise FileExistsError(f'{output} has prepared data. Remove the folder before re-preparing to avoid stale files.')

    records = _collect_gtsdb(gtsdb_zip) + _collect_roboflow(roboflow_zip)
    if extra_root:
        records += _collect_extra(Path(extra_root).expanduser().resolve())

    # Only classes occurring in training are predictable, never use test labels
    # to choose class indices or train parameters.
    active_names = {name for r in records if r.split == 'train' for name in r.names if name}
    order = {name: idx for idx, name in enumerate(GTSDB_NAMES)}
    class_names = sorted(active_names, key=lambda n: (0, order[n]) if n in order else (1, n))
    class_to_id = {n: i for i, n in enumerate(class_names)}
    (output / 'detection').mkdir(parents=True, exist_ok=True)
    (output / 'classification').mkdir(parents=True, exist_ok=True)
    (output / 'classes.json').write_text(json.dumps(class_names, indent=2, ensure_ascii=False), encoding='utf8')

    rows = {s: [] for s in ('train', 'val', 'test')}
    stats = {s: {'images': 0, 'boxes': 0, 'crops': 0, 'unknown_class_boxes': 0} for s in rows}
    train_counts = Counter()
    source_counts = Counter()
    with zipfile.ZipFile(gtsdb_zip) as gz, zipfile.ZipFile(roboflow_zip) as rz:
        zips = {'gtsdb': gz, 'roboflow': rz}
        for n, record in enumerate(records):
            split = record.split
            stem = f'{record.source}_{record.source_split}_{n:06d}'
            data = _load_original(record, zips)
            try:
                with Image.open(io.BytesIO(data)) as im:
                    # Apply EXIF orientation consistently for detector and crop.
                    image = ImageOps.exif_transpose(im).convert('RGB')
            except (UnidentifiedImageError, OSError) as exc:
                raise ValueError(f'Corrupt image {record.img_ref}') from exc
            width, height = image.size
            detect_img_dir = output / 'detection' / 'images' / split
            detect_lbl_dir = output / 'detection' / 'labels' / split
            detect_img_dir.mkdir(parents=True, exist_ok=True)
            detect_lbl_dir.mkdir(parents=True, exist_ok=True)
            # Re-encode for consistent RGB, PNG/JPEG input, and image dimensions.
            image.save(detect_img_dir / f'{stem}.jpg', format='JPEG', quality=92)
            detect_lines = []
            for bi, (box, name) in enumerate(zip(record.boxes, record.names)):
                detect_lines.append(f'0 {box.xc:.8f} {box.yc:.8f} {box.w:.8f} {box.h:.8f}')
                stats[split]['boxes'] += 1
                if name not in class_to_id:
                    stats[split]['unknown_class_boxes'] += 1
                    continue
                x1, y1, x2, y2 = _box_pixels(box, width, height)
                if x2 <= x1 or y2 <= y1:
                    continue
                crop = image.crop((x1, y1, x2, y2))
                crop_dir = output / 'classification' / 'images' / split
                crop_dir.mkdir(parents=True, exist_ok=True)
                crop_name = f'{stem}_{bi:03d}.jpg'
                crop.save(crop_dir / crop_name, quality=95)
                rows[split].append({'image': f'images/{split}/{crop_name}', 'label': class_to_id[name], 'source': record.source})
                stats[split]['crops'] += 1
                if split == 'train':
                    train_counts[name] += 1
            (detect_lbl_dir / f'{stem}.txt').write_text('\n'.join(detect_lines) + ('\n' if detect_lines else ''), encoding='utf8')
            stats[split]['images'] += 1
            source_counts[f'{record.source}/{split}'] += 1

    for split in rows:
        with (output / 'classification' / f'{split}.csv').open('w', newline='', encoding='utf8') as f:
            writer = csv.DictWriter(f, fieldnames=['image', 'label', 'source'])
            writer.writeheader()
            writer.writerows(rows[split])

    yaml_conf = {
        'path': str((output / 'detection').resolve()).replace('\\', '/'),
        'train': 'images/train', 'val': 'images/val', 'test': 'images/test',
        'nc': 1, 'names': ['traffic_control_object'],
    }
    (output / 'detection' / 'data.yaml').write_text(yaml.safe_dump(yaml_conf, sort_keys=False), encoding='utf8')
    summary = {
        'description': 'Detector has 1 class (signs + annotated traffic lights), CNN predicts the sign name.',
        'stats': stats, 'sources': dict(source_counts),
        'class_names': class_names, 'train_class_counts': dict(train_counts),
        'notes': [
            'Unknown GTSDB test class ID 100 is detected but excluded from classification accuracy.',
            'Classes seen only in validation/test are excluded from the classifier (no training examples).',
            'Very rare classes may not generalize; validation/test contain some near-duplicate source images.',
        ],
    }
    (output / 'summary.json').write_text(json.dumps(summary, indent=2, ensure_ascii=False), encoding='utf8')
    return summary
