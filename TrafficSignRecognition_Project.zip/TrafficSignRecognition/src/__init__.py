"""Traffic sign recognition project package."""
