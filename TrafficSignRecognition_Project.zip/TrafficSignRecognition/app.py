"""Local traffic-sign image recognition app: streamlit run app.py"""
from pathlib import Path

import pandas as pd
import streamlit as st
from PIL import Image, ImageOps, UnidentifiedImageError

from src.inference import load_models, classify_and_annotate, png_bytes

st.set_page_config(page_title='Traffic Sign Recognition', page_icon='🚦', layout='wide')
st.title('🚦 Traffic Sign Recognition')
st.write('Upload a road photograph. The detector locates traffic-control objects, '
         'and your trained PyTorch CNN identifies each sign.')

ROOT = Path(__file__).resolve().parent
DET_PATH = ROOT / 'models' / 'sign_detector.pt'
CLS_PATH = ROOT / 'models' / 'sign_classifier.pt'
with st.sidebar:
    st.header('Inference settings')
    det_threshold = st.slider('Detection confidence threshold', min_value=.05, max_value=.90, value=.25, step=.05)
    class_threshold = st.slider('Minimum classification score', min_value=.05, max_value=.95, value=.45, step=.05)
    imgsz = st.select_slider('Detector image size', options=[416, 512, 640, 800, 960], value=640)
    st.caption('Higher resolution can help detect small signs, but may be slower.')
    st.divider()
    st.caption('Run locally; the app does not upload your road images to a remote API.')

ready = DET_PATH.is_file() and CLS_PATH.is_file()
if not ready:
    st.warning('Full-road recognition needs BOTH trained model checkpoints. '
               'Run data preparation, CNN training (if missing), and YOLO detector training.')
    if not CLS_PATH.is_file():
        st.code('python train_classifier.py --epochs 15')
    if not DET_PATH.is_file():
        st.code('python train_detector.py --epochs 35 --imgsz 640 --batch 8')

@st.cache_resource(show_spinner='Loading trained models...')
def models():
    return load_models(DET_PATH, CLS_PATH)

uploaded = st.file_uploader('Choose a road image', type=['jpg', 'jpeg', 'png'])
if uploaded is not None:
    try:
        # Avoid PIL decompression bombs and unbounded memory use.
        Image.MAX_IMAGE_PIXELS = 20_000_000
        with Image.open(uploaded) as data:
            road_image = ImageOps.exif_transpose(data).convert('RGB')
        if road_image.width * road_image.height > 20_000_000:
            raise ValueError('Please upload a photo smaller than 20 megapixels.')
    except (UnidentifiedImageError, OSError, ValueError) as exc:
        st.error(f'Could not open image: {exc}')
        st.stop()

    if not ready:
        st.image(road_image, caption='Input image — train the models to enable recognition', use_container_width=True)
        st.stop()

    try:
        detector, classifier, names, device = models()
        with st.spinner('Detecting and classifying traffic signs...'):
            annotated, signs = classify_and_annotate(road_image, detector, classifier,
                names, device, det_threshold, class_threshold, imgsz)
    except Exception as exc:
        st.error(f'Inference failed: {exc}')
        st.stop()

    left, right = st.columns(2)
    with left:
        st.image(road_image, caption='Original road image', use_container_width=True)
    with right:
        st.image(annotated, caption='Detected traffic signs', use_container_width=True)
    st.metric('Signs / annotated traffic lights detected', len(signs))
    if signs:
        st.dataframe(pd.DataFrame([{
            'Sign': x['sign'],
            'Detection score': round(x['detection_confidence'], 3),
            'Classification score': round(x['class_confidence'], 3),
            'Bounding box (x1,y1,x2,y2)': str(x['box']),
        } for x in signs]), use_container_width=True, hide_index=True)
    else:
        st.info('No signs detected at this threshold. Try a lower detection threshold or a higher image size.')
    st.download_button('Download annotated image', data=png_bytes(annotated),
                       file_name='traffic_sign_result.png', mime='image/png')
    st.caption('Model confidence is not the same as guaranteed correctness. '
               'Unknown signs and difficult road conditions may cause incorrect predictions.')
